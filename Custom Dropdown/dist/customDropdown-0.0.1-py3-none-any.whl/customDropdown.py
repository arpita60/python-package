from dash import Dash, html, dcc, callback, Output, Input

def customDropdown():
    print('hello from package')